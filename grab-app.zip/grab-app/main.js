const { app, BrowserWindow, ipcMain, desktopCapturer, dialog, Tray, Menu, globalShortcut, nativeImage, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');

let mainWindow = null;
let tray = null;

// ── Create main window ──
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 900,
    minHeight: 600,
    frame: false,
    titleBarStyle: 'hidden',
    backgroundColor: '#0a0b0d',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    },
    icon: path.join(__dirname, 'assets', process.platform === 'win32' ? 'icon.ico' : 'icon.png')
  });

  mainWindow.loadFile('index.html');

  mainWindow.on('close', (e) => {
    e.preventDefault();
    mainWindow.hide();
  });
}

// ── Tray ──
function createTray() {
  const iconPath = path.join(__dirname, 'assets', process.platform === 'win32' ? 'tray.ico' : 'tray.png');
  const fallback = nativeImage.createEmpty();

  try {
    tray = new Tray(fs.existsSync(iconPath) ? iconPath : fallback);
  } catch {
    tray = new Tray(fallback);
  }

  const contextMenu = Menu.buildFromTemplate([
    { label: 'Abrir Grab', click: () => { mainWindow.show(); mainWindow.focus(); } },
    { type: 'separator' },
    { label: '⏺  Iniciar grabación', click: () => mainWindow.webContents.send('shortcut-record') },
    { label: '⚡ Instant Replay', click: () => mainWindow.webContents.send('shortcut-replay') },
    { label: '📷 Captura de pantalla', click: () => mainWindow.webContents.send('shortcut-screenshot') },
    { type: 'separator' },
    { label: 'Salir', click: () => { app.exit(0); } }
  ]);

  tray.setToolTip('Grab — Screen Recorder');
  tray.setContextMenu(contextMenu);
  tray.on('double-click', () => { mainWindow.show(); mainWindow.focus(); });
}

// ── App ready ──
app.whenReady().then(() => {
  createWindow();
  createTray();
  registerShortcuts();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});

app.on('will-quit', () => {
  globalShortcut.unregisterAll();
});

// ── Global shortcuts ──
function registerShortcuts() {
  globalShortcut.register('CommandOrControl+Shift+R', () => {
    mainWindow.webContents.send('shortcut-record');
  });
  globalShortcut.register('CommandOrControl+Shift+P', () => {
    mainWindow.webContents.send('shortcut-pause');
  });
  globalShortcut.register('F10', () => {
    mainWindow.webContents.send('shortcut-replay');
  });
  globalShortcut.register('F11', () => {
    mainWindow.webContents.send('shortcut-screenshot');
  });
  globalShortcut.register('CommandOrControl+Shift+L', () => {
    mainWindow.webContents.send('shortcut-live');
  });
}

// ── IPC Handlers ──

// Get screen sources for capture selector
ipcMain.handle('get-sources', async () => {
  const sources = await desktopCapturer.getSources({
    types: ['window', 'screen'],
    thumbnailSize: { width: 320, height: 180 }
  });
  return sources.map(s => ({
    id: s.id,
    name: s.name,
    thumbnail: s.thumbnail.toDataURL()
  }));
});

// Save recording to disk
ipcMain.handle('save-recording', async (event, { buffer, filename }) => {
  const downloadsPath = app.getPath('downloads');
  const grabFolder = path.join(downloadsPath, 'Grab');
  if (!fs.existsSync(grabFolder)) fs.mkdirSync(grabFolder, { recursive: true });

  const filePath = path.join(grabFolder, filename);
  fs.writeFileSync(filePath, Buffer.from(buffer));
  return { success: true, path: filePath };
});

// Open recordings folder
ipcMain.handle('open-folder', async () => {
  const grabFolder = path.join(app.getPath('downloads'), 'Grab');
  if (!fs.existsSync(grabFolder)) fs.mkdirSync(grabFolder, { recursive: true });
  shell.openPath(grabFolder);
});

// Get system info
ipcMain.handle('get-system-info', () => {
  return {
    platform: process.platform,
    arch: process.arch,
    cpus: os.cpus().length,
    totalMem: Math.round(os.totalmem() / 1e9) + ' GB',
    freeMem: Math.round(os.freemem() / 1e9) + ' GB',
    homeDir: os.homedir(),
    savePath: path.join(app.getPath('downloads'), 'Grab')
  };
});

// Window controls
ipcMain.on('minimize-window', () => mainWindow.minimize());
ipcMain.on('maximize-window', () => {
  if (mainWindow.isMaximized()) mainWindow.unmaximize();
  else mainWindow.maximize();
});
ipcMain.on('close-window', () => mainWindow.hide());
ipcMain.on('quit-app', () => app.exit(0));
ipcMain.on('show-window', () => { mainWindow.show(); mainWindow.focus(); });
