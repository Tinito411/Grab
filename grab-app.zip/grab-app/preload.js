const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('grabAPI', {
  // Sources
  getSources: () => ipcRenderer.invoke('get-sources'),

  // File operations
  saveRecording: (data) => ipcRenderer.invoke('save-recording', data),
  openFolder: () => ipcRenderer.invoke('open-folder'),

  // System
  getSystemInfo: () => ipcRenderer.invoke('get-system-info'),

  // Window controls
  minimize: () => ipcRenderer.send('minimize-window'),
  maximize: () => ipcRenderer.send('maximize-window'),
  close: () => ipcRenderer.send('close-window'),
  quit: () => ipcRenderer.send('quit-app'),
  show: () => ipcRenderer.send('show-window'),

  // Shortcut listeners
  onShortcut: (callback) => {
    ipcRenderer.on('shortcut-record', () => callback('record'));
    ipcRenderer.on('shortcut-pause', () => callback('pause'));
    ipcRenderer.on('shortcut-replay', () => callback('replay'));
    ipcRenderer.on('shortcut-screenshot', () => callback('screenshot'));
    ipcRenderer.on('shortcut-live', () => callback('live'));
  }
});
