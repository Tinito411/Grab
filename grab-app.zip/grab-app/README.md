# ⚡ Grab — Screen Recorder for Gamers

App de escritorio liviana para grabar pantalla, hacer directos y capturar momentos épicos.

---

## Requisitos

- [Node.js](https://nodejs.org/) v18 o superior
- npm (viene con Node.js)

---

## Instalación y ejecución

```bash
# 1. Entrá a la carpeta
cd grab-app

# 2. Instalá las dependencias (solo la primera vez)
npm install

# 3. Ejecutá la app
npm start
```

---

## Compilar instalador (opcional)

```bash
# Windows (.exe instalador)
npm run build-win

# macOS (.dmg)
npm run build-mac

# Linux (.AppImage)
npm run build-linux
```

El ejecutable aparece en la carpeta `dist/`.

---

## Características

| Feature | Descripción |
|---|---|
| ⏺ Grabar pantalla | Capturá cualquier ventana, monitor o pestaña |
| ⚡ Instant Replay | Guardá los últimos N segundos con F10 |
| 📡 Modo Directo | Configuración RTMP para Twitch, YouTube, Kick |
| 📷 Screenshot | Captura de pantalla con F11 |
| ⌨ Atajos globales | Funcionan aunque la app esté minimizada |
| 🔔 Bandeja del sistema | Siempre disponible en segundo plano |
| ⚙ Configuración | Resolución, FPS, bitrate, encoder, audio |

## Atajos de teclado

| Atajo | Acción |
|---|---|
| Ctrl+Shift+R | Iniciar / Detener grabación |
| Ctrl+Shift+P | Pausar / Reanudar |
| F10 | Instant Replay |
| F11 | Captura de pantalla |
| Ctrl+Shift+L | Iniciar / Detener directo |
| F9 | Silenciar micrófono |

## Grabaciones

Las grabaciones se guardan automáticamente en:
- **Windows**: `C:\Users\[usuario]\Downloads\Grab\`
- **macOS**: `~/Downloads/Grab/`
- **Linux**: `~/Downloads/Grab/`

## Notas técnicas

- Usa Electron + la API nativa `desktopCapturer` para captura real de pantalla
- El streaming RTMP requiere un servidor intermediario (ffmpeg, Nginx RTMP, etc.)
- Pesa ~150 MB instalada (Electron runtime incluido)
